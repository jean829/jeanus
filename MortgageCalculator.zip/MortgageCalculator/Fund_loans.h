#ifndef FUND_LOANS_H
#define FUND_LOANS_H
#include<cmath>
class Fund_loans
{
public:
    Fund_loans();
    Fund_loans(double loan1,double rate1,int month1);
    void equal_interest();//等额本息
    void equal_principal();//等额本金
    double Getloan() { return loan; }//贷款总额
    double Getrate() { return rate; }//贷款利率
    double Getmonth() { return month; }//还款时间
    double Gett_repay() { return t_repayment; }//还款总额
    double Getinterest() { return interest; }//利息
    double Getm_supply() { return m_supply;}//每月月供
    double Getf_supply() { return f_supply; }//首月月供
    double Getm_re() { return m_reduce; }//每月差值
    void Setloan(double l) { loan=l; }
    void Setrate(double r) { rate=r; }
    void Setmonth(int m) { month=m; }
private:
    double loan;//贷款总额
    double rate;//贷款利率
    int month;//还款时间
    double t_repayment;//还款总额
    double interest;//利息
    double m_supply;//每月月供
    double f_supply;//首月月供
    double m_reduce;//两个相邻月份所交利息的差值
};
Fund_loans::Fund_loans()
{
   loan=0.0;rate=0.0;month=0;t_repayment=0.0;interest=0.0;m_supply=0.0;f_supply=0.0;m_reduce=0.0;
}
Fund_loans::Fund_loans(double loan1,double rate1,int month1)
{
    loan=loan1;rate=rate1/100.0;month=month1;t_repayment=0.0;interest=0.0;m_supply=0.0;f_supply=0.0;m_reduce=0.0;
}
void Fund_loans::equal_interest()//计算等额本息
{
    m_supply=(loan*(rate/12.0)*pow((1+rate/12.0),month))/(pow((1+rate/12.0),month)-1);
    t_repayment=m_supply*month;
    interest=t_repayment-loan;
}
void Fund_loans::equal_principal()//计算等额本金
{
    double principal=loan/month;
    t_repayment=loan+(month+1)*loan*(rate/12.0)/2.0;
    interest=t_repayment-loan;
    f_supply=principal+loan*(rate/12.0);
    m_reduce=loan*rate/12.0-(loan-principal)*rate/12.0;
}
#endif // FUND_LOANS_H
