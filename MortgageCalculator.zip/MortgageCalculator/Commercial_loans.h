#ifndef COMMERCIAL_LOANS_H
#define COMMERCIAL_LOANS_H
#include "Fund_loans.h"
class Commercial_loans:virtual public Fund_loans
{
public:
    Commercial_loans (double area1, double unit_price1, double rate1, double percent1,int month1);
    double Getarea() { return area;}//房屋面积
    void Setarea(double a) { area=a; }
    double Getprice() { return unit_price;}//房屋单价
    void Setprice(double p) { unit_price=p; }
    double Getpercent() { return percent; }//按揭成数
    void Setpercent(double pe) { percent=pe; }
    double Getf_payment() { return f_payment; }//首付
    void Setf_payment(double pay) { f_payment=pay; }

private:
    double f_payment;//首付
    double area;//房屋面积
    double unit_price;//房屋单价
    double percent;//按揭成数
};
Commercial_loans::Commercial_loans(double area1, double unit_price1, double rate1, double percent1,int month1):Fund_loans(unit_price1*area1*percent1,rate1,month1)
{
    area=area1;unit_price=unit_price1;;percent=percent1;
    f_payment=unit_price*area-unit_price*area*percent;
}
#endif // COMMERCIAL_LOANS_H
