#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Commercial_loans.h"
#include "Fund_loans.h"
#include "QString"
//Mcalculator
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::closeEvent(QCloseEvent *close)
{

    int option = QMessageBox::question(this,"Question","是否关闭房贷计算器？");
    if(option == QMessageBox::Yes)
    {
        close->accept();//取消传递事件
    }
    else if(option == QMessageBox::No)
    {
        close->ignore();//事件继续传递
    }
}
//a为贷款模式,b为year的序号,c为利率的序号,返回值为正确利率
double optionrate(int a,int b, int c)
{
    if(a==0)
    {
        if(b<20)
        {
            switch (c)
            {
            case 0:return 4.65;//2020.4.20
            case 1:return 4.75;//2020.3.20
            case 2:return 4.85;//2019.9.20
            case 3:return 5.39;//2015.10.24
            case 4:return 5.15;
            case 5:return 4.17;
            case 6:return 3.43;
            case 7:return 4.9;
            case 8:return 5.67;//2015.8.26
            case 9:return 4.38;
            case 10:return 3.61;
            case 11:return 5.15;
            case 12:return 5.94;//2015.6.28
            case 13:return 4.59;
            case 14:return 3.78;
            case 15:return 5.4;
            case 16:return 6.22;//2015.5.11
            case 17:return 4.8;
            case 18:return 3.96;
            case 19:return 5.65;
            case 20:return 6.49;//2015.3.1
            case 21:return 5.01;
            case 22:return 4.13;
            case 23:return 5.9;
            case 24:return 6.7;//2014.11.22
            case 25:return 5.2;
            case 26:return 4.3;
            case 27:return 6.15;
            case 28:return 7.21;//2012.7.6
            case 29:return 5.57;
            case 30:return 4.59;
            case 31:return 6.55;
            case 32:return 7.48;//2012.6.8
            case 33:return 5.78;
            case 34:return 4.76;
            case 35:return 6.8;
            }
        }
        else
        {
            switch (c)
            {
            case 0:return 3.85;//2020.4.20
            case 1:return 4.05;//2020.3.20
            case 2:return 4.2;//2019.9.20
            case 3:return 5.23;//2015.10.24
            case 4:return 4.99;
            case 5:return 4.04;
            case 6:return 3.33;
            case 7:return 4.75;
            case 8:return 5.5;//2015.8.26
            case 9:return 4.25;
            case 10:return 3.5;
            case 11:return 5;
            case 12:return 5.78;//2015.6.28
            case 13:return 4.46;
            case 14:return 3.68;
            case 15:return 5.25;
            case 16:return 6.05;//2015.5.11
            case 17:return 4.68;
            case 18:return 3.85;
            case 19:return 5.5;
            case 20:return 6.33;//2015.3.1
            case 21:return 4.89;
            case 22:return 4.03;
            case 23:return 5.75;
            case 24:return 6.6; //2014.11.22
            case 25:return 5.1;
            case 26:return 4.2;
            case 27:return 6;
            case 28:return 6.77;//2012.7.6
            case 29:return 5.23;
            case 30:return 4.31;
            case 31:return 6.15;
            case 32:return 7.04;//2012.6.8
            case 33:return 5.44;
            case 34:return 6.4;
            }
        }
    }
    else
    {
        if(b<20)
        {
            switch (c)
            {
            case 0:return 3.25;//2020.4.20
            case 1:return 3.25;//2020.3.20
            case 2:return 3.25;//2019.9.20
            case 3:return 3.57;//2015.10.24
            case 4:return 3.41;
            case 5:return 2.76;
            case 6:return 2.28;
            case 7:return 3.25;
            case 8:return 3.57;//2015.8.26
            case 9:return 2.76;
            case 10:return 2.28;
            case 11:return 3.25;
            case 12:return 3.57;//2015.6.28
            case 13:return 2.98;
            case 14:return 2.45;
            case 15:return 3.5;
            case 16:return 4.13;//2015.5.11
            case 17:return 3.19;
            case 18:return 2.63;
            case 19:return 3.75;
            case 20:return 4.4;//2015.3.1
            case 21:return 3.4;
            case 22:return 2.8;
            case 23:return 4;
            case 24:return 4.25;//2014.11.22
            case 25:return 4.25;
            case 26:return 4.25;
            case 27:return 4.25;
            case 28:return 4.5;//2012.7.6
            case 29:return 4.5;
            case 30:return 4.5;
            case 31:return 4.5;
            case 32:return 4.7;//2012.6.8
            case 33:return 4.7;
            case 34:return 4.7;
            case 35:return 4.7;
            }
        }
        else
        {
            switch (c)
            {
            case 0:return 2.75;//2020.4.20
            case 1:return 2.75;//2020.3.20
            case 2:return 2.75;//2019.9.20
            case 3:return 3.03;//2015.10.24
            case 4:return 2.89;
            case 5:return 2.34;
            case 6:return 1.93;
            case 7:return 2.75;
            case 8:return 3.03;//2015.8.26
            case 9:return 2.34;
            case 10:return 1.93;
            case 11:return 2.75;
            case 12:return 3.3; //2015.6.28
            case 13:return 2.55;
            case 14:return 2.1;
            case 15:return 3;
            case 16:return 3.57;//2015.5.11
            case 17:return 2.76;
            case 18:return 2.28;
            case 19:return 3.25;
            case 20:return 3.85;//2015.3.1
            case 21:return 2.97;
            case 22:return 2.45;
            case 23:return 3.5;
            case 24:return 3.75;//2014.11.22
            case 25:return 3.75;
            case 26:return 3.75;
            case 27:return 3.75;
            case 28:return 4;//2012.7.6
            case 29:return 4;
            case 30:return 4;
            case 31:return 4;
            case 32:return 4.2;//2012.6.8
            case 33:return 4.2;break;
            case 34:return 4.2;
            case 35:return 4.2;
            }
        }
    }
    return 0;
}
double optionrate1(int b,int c)
{
        if(b<20)
        {
            switch(c)
            {
            case 0:return 3.25;
            case 1:return 3.25;
            case 2:return 3.57;
            case 3:return 3.41;
            case 4:return 2.76;
            case 5:return 2.28;
            case 6:return 3.25;
            case 7:return 3.57;
            case 8:return 2.76;
            case 9:return 2.28;
            case 10:return 3.25;
            case 11:return 3.85;
            case 12:return 2.98;
            case 13:return 2.45;
            case 14:return 3.5;
            case 15:return 4.13;
            case 16:return 3.19;
            case 17:return 2.63;
            case 18:return 3.75;
            case 19:return 4.4;
            case 20:return 3.4;
            case 21:return 2.8;
            case 22:return 4;
            case 23:return 4.25;
            case 24:return 4.25;
            case 25:return 4.25;
            case 26:return 4.25;
            case 27:return 4.5;
            case 28:return 4.5;
            case 29:return 4.5;
            case 30:return 4.5;
            case 31:return 4.7;
            case 32:return 4.7;
            case 33:return 4.7;
            case 34:return 4.7;
            }
        }
        else
        {
            switch(c)
            {
            case 0:return 2.75;
            case 1:return 2.75;
            case 2:return 3.03;
            case 3:return 2.89;
            case 4:return 2.34;
            case 5:return 1.93;
            case 6:return 2.75;
            case 7:return 3.03;
            case 8:return 2.34;
            case 9:return 1.93;
            case 10:return 2.75;
            case 11:return 3.3;
            case 12:return 2.55;
            case 13:return 2.1;
            case 14:return 3;
            case 15:return 3.57;
            case 16:return 2.76;
            case 17:return 2.28;
            case 18:return 3.25;
            case 19:return 3.85;
            case 20:return 2.97;
            case 21:return 2.45;
            case 22:return 3.5;
            case 23:return 3.75;
            case 24:return 3.75;
            case 25:return 3.75;
            case 26:return 3.75;
            case 27:return 4;
            case 28:return 4;
            case 29:return 4;
            case 30:return 4;
            case 31:return 4.2;
            case 32:return 4.2;
            case 33:return 4.2;
            case 34:return 4.2;
            }
        }
        return 0;
}
int optionmonth(int a)
{
    int month;
    switch (a)
    {
    case 0:month = 300;break;
    case 1:month = 288;break;
    case 2:month = 276;break;
    case 3:month = 264;break;
    case 4:month = 252;break;
    case 5:month = 240;break;
    case 6:month = 228;break;
    case 7:month = 216;break;
    case 8:month = 204;break;
    case 9:month = 192;break;
    case 10:month = 180;break;
    case 11:month = 168;break;
    case 12:month = 156;break;
    case 13:month = 144;break;
    case 14:month = 132;break;
    case 15:month = 120;break;
    case 16:month = 108;break;
    case 17:month = 96;break;
    case 18:month = 84;break;
    case 19:month = 72;break;
    case 20:month = 60;break;
    case 21:month = 48;break;
    case 22:month = 36;break;
    case 23:month = 24;break;
    case 24:month = 12;break;
    }
    return month;
}
double optionpercent(int a)
{
    double percent;
    switch (a)
    {
    case 0:percent = 0.8;break;
    case 1:percent = 0.75;break;
    case 2:percent = 0.7;break;
    case 3:percent = 0.65;break;
    case 4:percent = 0.6;break;
    case 5:percent = 0.55;break;
    case 6:percent = 0.5;break;
    case 7:percent = 0.45;break;
    case 8:percent = 0.4;break;
    case 9:percent = 0.35;break;
    case 10:percent = 0.3;break;
    case 11:percent = 0.25;break;
    case 12:percent = 0.2;break;
    }
    return percent;
}
//page
void MainWindow::on_comboBox_c_loan1_currentIndexChanged(int index)
{
    if(index==2)
    {
        ui->comboBox_c_loan3->setCurrentIndex(0);
        ui->comboBox_c_loan1->setCurrentIndex(0);
        ui->comboBox_calculation1->setCurrentIndex(0);
        ui->lineEdit_price1->clear();
        ui->lineEdit_area1->clear();
        ui->comboBox_percent1->setCurrentIndex(0);
        ui->comboBox_year1->setCurrentText(0);
        ui->comboBox_rate1->setCurrentText(0);
        ui->lineEdit_rate1->setText("4.65");
        ui->stackedWidget->setCurrentWidget(ui->page_5);
    }
    else
    {
            if(index==0)
            ui->lineEdit_rate1->setText("4.65");
            else
            ui->lineEdit_rate1->setText("3.25");
     }
}
void MainWindow::on_comboBox_calculation1_currentIndexChanged(int index)
{
    if(index == 1)
    {
        ui->comboBox_c_loan2->setCurrentIndex(ui->comboBox_c_loan1->currentIndex());//贷款模式
        if(ui->comboBox_c_loan2->currentIndex()==0)
          ui->lineEdit_rate2->setText("4.65");
        else
          ui->lineEdit_rate2->setText("3.25");
        ui->comboBox_calculation2->setCurrentIndex(0);
        ui->comboBox_c_loan1->setCurrentIndex(0);
        ui->lineEdit_price1->clear();
        ui->lineEdit_area1->clear();
        ui->comboBox_percent1->setCurrentIndex(0);
        ui->comboBox_year1->setCurrentText(0);
        ui->comboBox_rate1->setCurrentText(0);
        ui->lineEdit_rate1->setText("4.65");
        ui->stackedWidget->setCurrentWidget(ui->page_3);
    }
}

int MainWindow::on_comboBox_year1_currentIndexChanged(int index)
{
    double a;
    a=optionrate(ui->comboBox_c_loan1->currentIndex(),index,ui->comboBox_rate1->currentIndex());
    QString b=QString::number(a);
    ui->lineEdit_rate1->setText(b);
  int month;
  month=optionmonth(index);
  return month;
}

void MainWindow::on_comboBox_rate1_currentIndexChanged(int index)
{
    double a;
    if(ui->comboBox_c_loan1==0) a=4.65;
    else a=3.25;
    a=optionrate(ui->comboBox_c_loan1->currentIndex(),ui->comboBox_year1->currentIndex(),index);
    QString b=QString::number(a);
    ui->lineEdit_rate1->setText(b);
}

void MainWindow::on_pushButton_start1_clicked()
{
    QString Yprice = ui->lineEdit_price1->text();
    QString Yarea = ui->lineEdit_area1->text();
    QString Yrate = ui->lineEdit_rate1->text();
    double price = ui->lineEdit_price1->text().toDouble();//房屋单价
    double area = ui->lineEdit_area1->text().toDouble();//房屋面积
    int month =on_comboBox_year1_currentIndexChanged(ui->comboBox_year1->currentIndex());//贷款年数
    bool judge = 0;
    double rate = 0;
    //判断是否为空
    if(!Yprice.isEmpty()&&!Yarea.isEmpty())
    {
        int Ypoint = 0,Yelse=0;
        bool flag1 = 0, flag2 = 0,flag3 = 0;
        for(int i= 0 ;i<Yprice.length();i++)//判断输入单价
        {
            if((Yprice[i]<='9'&&Yprice[i]>='0')||Yprice[i]=='.')
            {
                if(Yprice[i]=='.')
                    Ypoint++;//计算小数点个数
            }
            else Yelse++;//计算非数字\小数点字符个数
            if(Ypoint>1||Yelse!=0){flag1=1;break;}//如果小数点超过一个或者有非数字的情况判断输入为错
        }
        Ypoint = 0;
        Yelse=0;//判断输入面积
        for(int i= 0 ;i<Yarea.length();i++)
        {
            if((Yarea[i]<='9'&&Yarea[i]>='0')||Yarea[i]=='.')
            {
                if(Yarea[i]=='.')
                    Ypoint++;    //计算小数点个数
            }
            else Yelse++;//计算非数字\小数点字符个数
            if(Ypoint>1||Yelse!=0){flag2=1;break;}//如果小数点超过一个或者有非数字的情况判断输入为错
        }
        Ypoint = 0;
        Yelse=0;//判断输入利率
        for(int i= 0 ;i<Yrate.length();i++)
        {
            if((Yrate[i]<='9'&&Yrate[i]>='0')||Yrate[i]=='.')
            {
                if(Yrate[i]=='.')
                    Ypoint++;//计算小数点个数
            }
            else Yelse++;//计算非数字\小数点字符个数
            if(Ypoint>1||Yelse!=0||Yrate.toDouble()==0.0){flag3=1;break;}//如果小数点超过一个或者有非数字的情况判断输入为错
            else rate=Yrate.toDouble();
        }

        if(flag1 == 1 && flag2 == 1 && flag3 == 1)
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您的输入的房屋单价、面积、利率有误",QMessageBox::Ok);
        }
        else if(flag1 == 1 && flag2 == 0 && flag3 == 0)
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您的输入房屋单价有误",QMessageBox::Ok);
        }
        else if(flag1 == 0 && flag2 == 1 && flag3 == 0)
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您的输入房屋面积有误",QMessageBox::Ok);
        }
        else if(flag1 == 0 && flag2 == 0 && flag3 == 1)
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您的输入房屋利率不合法，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 == 1 && flag2 == 0 && flag3 == 1)
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您的输入房屋单价、利率有误",QMessageBox::Ok);
        }
        else if(flag1 == 0 && flag2 == 1 && flag3 == 1)
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您的输入房屋面积、利率有误",QMessageBox::Ok);
        }
        else if(flag1 == 1 && flag2 == 1 && flag3 == 0)
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您的输入房屋单价、面积有误",QMessageBox::Ok);
        }
        else
        {
            judge = 1;
        }
    }
    //如果有输入有空
    else
    {
        if(Yprice.isEmpty()&&Yarea.isEmpty()&&Yrate.isEmpty())
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","请输入房屋单价、面积、利率",QMessageBox::Ok);
        }
        else if(Yprice.isEmpty()&&!Yarea.isEmpty()&&!Yrate.isEmpty())
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","请输入房屋单价",QMessageBox::Ok);
        }
        else if(!Yprice.isEmpty()&&Yarea.isEmpty()&&!Yrate.isEmpty())
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","请输入房屋面积",QMessageBox::Ok);
        }
        else if(!Yprice.isEmpty()&&!Yarea.isEmpty()&&Yrate.isEmpty())
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","请输入房屋利率",QMessageBox::Ok);
        }
        else if(!Yprice.isEmpty()&&Yarea.isEmpty()&&Yrate.isEmpty())
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","请输入房屋面积、利率",QMessageBox::Ok);
        }
        else if(Yprice.isEmpty()&&!Yarea.isEmpty()&&Yrate.isEmpty())
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","请输入房屋单价、利率",QMessageBox::Ok);
        }
        else if(Yprice.isEmpty()&&Yarea.isEmpty()&&!Yrate.isEmpty())
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","请输入房屋面积、单价",QMessageBox::Ok);
        }
    }

    if(judge ==1 )
    {
        double percent = 0;//按揭成数
        percent=optionpercent(ui->comboBox_percent1->currentIndex());
         rate = Yrate.toDouble();
        ui->comboBox_c_loan1_2->setCurrentIndex(ui->comboBox_c_loan1->currentIndex());//更新下一页贷款模式
        ui->comboBox_calculation1_2->setCurrentIndex(ui->comboBox_calculation1->currentIndex());//更新下一页数据（计算方式）
        ui->lineEdit_price1_2->setText(ui->lineEdit_price1->text());//更新下一页数据（单价）
        ui->lineEdit_area1_2->setText(ui->lineEdit_area1->text());//更新下一页数据（房屋面积）
        ui->comboBox_percent1_2->setCurrentIndex(ui->comboBox_percent1->currentIndex());//更新下一页数据（按揭成数）
        ui->comboBox_year1_2->setCurrentIndex(ui->comboBox_year1->currentIndex());//更新下一页数据（日期）
        ui->comboBox_rate1_2->setCurrentIndex(ui->comboBox_rate1->currentIndex());//更新下一页利率选项
        ui->lineEdit_rate1_2->setText(Yrate);//更新下一页利率
  //调用商贷构造函数
         Commercial_loans  A(area, price,  rate, percent, month);
 //选用哪种利息方式（等额本息）
        if(ui->radioButton_bx1->isChecked())
        {
            ui->widget_m_pay1->show();//选择为本息：展示的为每月月供
            ui->widget_fm_pay1->hide();//选择为本息：隐藏的为首月月供
            ui->widget_m_cut1->hide();//选择为本息：隐藏的为每月递减
            A.equal_interest();//等额本息
            ui->label_f_pay1->setText(QString::number(A.Getf_payment(), 'f', 1));//首付
            ui->label_m_pay1->setText(QString::number(A.Getm_supply(), 'f', 1));//每月月供
            ui->label_loans1->setText(QString::number(A.Getloan(), 'f', 1));//贷款总额
            ui->label_interest1->setText(QString::number(A.Getinterest(), 'f', 1));//支付利息
            ui->label_t_repay1->setText(QString::number(A.Gett_repay(), 'f', 1));//还款总额
            ui->label_m1->setText(QString::number(A.Getmonth(), 'f', 0));//还款月数
            ui->radioButton_bx1_2->click();
        }
        //等额本金
        else if(ui->radioButton_bj1->isChecked())
        {
            ui->widget_fm_pay1->show();//展示首月月供
            ui->widget_m_cut1->show();//展示每月递减
            ui->widget_m_pay1->hide();//选择为本息：隐藏的为每月月供
            A.equal_principal();//等额本金
            ui->label_f_pay1->setText(QString::number(A.Getf_payment(), 'f', 1));//首付
            ui->label_fm_pay1->setText(QString::number(A.Getf_supply(), 'f', 1));//首月月供
            ui->label_m_cut1->setText(QString::number(A.Getm_re(), 'f', 1));//每月递减
            ui->label_loans1->setText(QString::number(A.Getloan(), 'f', 1));//贷款总额
            ui->label_interest1->setText(QString::number(A.Getinterest(), 'f', 1));//支付利息
            ui->label_t_repay1->setText(QString::number(A.Gett_repay(), 'f', 1));//还款总额
            ui->label_m1->setText(QString::number(A.Getmonth(), 'f', 0));//还款月数
            ui->radioButton_bj1_2->click();
        }
        ui->comboBox_c_loan1->setCurrentIndex(0);
        ui->lineEdit_price1->clear();
        ui->lineEdit_area1->clear();
        ui->comboBox_percent1->setCurrentIndex(0);
        ui->comboBox_year1->setCurrentText(0);
        ui->comboBox_rate1->setCurrentText(0);
        ui->lineEdit_rate1->setText("4.65");
        ui->stackedWidget->setCurrentWidget(ui->page2);
    }
}

void MainWindow::on_pushButton_remove1_clicked()
{
    int reply = QMessageBox::question(this,"Question","是否需要清除数据？");
    if(reply == QMessageBox::Yes)
    {
        //把单价、面积两个数据清除，并把选项初始化;
        ui->lineEdit_price1->clear();
        ui->lineEdit_area1->clear();
        ui->comboBox_percent1->setCurrentIndex(0);
        ui->comboBox_year1->setCurrentText(0);
        ui->comboBox_rate1->setCurrentText(0);
        if(ui->comboBox_c_loan1->currentIndex() == 0)
            ui->lineEdit_rate1->setText("4.65");
        else
        {
            ui->lineEdit_rate1->setText("3.25");
        }
    }
        //否则继续传递
}
//page2
void MainWindow::on_comboBox_c_loan1_2_currentIndexChanged(int index)
{
    if(index==2)
    {

        ui->comboBox_c_loan3->setCurrentIndex(0);
       ui->comboBox_c_loan1_2->setCurrentIndex(0);
        ui->lineEdit_price1_2->clear();
        ui->lineEdit_area1_2->clear();
        ui->comboBox_percent1_2->setCurrentIndex(0);
        ui->comboBox_year1_2->setCurrentText(0);
        ui->comboBox_rate1_2->setCurrentText(0);
        ui->lineEdit_rate1_2->setText("4.65");
        ui->stackedWidget->setCurrentWidget(ui->page_5);
    }
    else
    {
        if(index==0)
        {
        ui->comboBox_c_loan1->setCurrentIndex(0);
        ui->lineEdit_rate1->setText("4.65");
        ui->stackedWidget->setCurrentWidget(ui->page);
        }
        else
        {
        ui->comboBox_c_loan1->setCurrentIndex(1);
        ui->lineEdit_rate1->setText("3.25");
        ui->stackedWidget->setCurrentWidget(ui->page);
        }
     }
}

void MainWindow::on_comboBox_calculation1_2_currentIndexChanged(int index)
{
    if(index == 1)
    {
            ui->comboBox_c_loan2->setCurrentIndex(ui->comboBox_c_loan1_2->currentIndex());
            if(ui->comboBox_c_loan2->currentIndex()==0)
                ui->lineEdit_rate2->setText("4.65");
                else
                ui->lineEdit_rate2->setText("3.25");
            ui->comboBox_calculation2->setCurrentIndex(0);
            ui->comboBox_c_loan1_2->setCurrentIndex(0);
            ui->comboBox_c_loan1_2->setCurrentIndex(0);
            ui->comboBox_year1_2->setCurrentText(0);
            ui->comboBox_rate1_2->setCurrentText(0);
            ui->lineEdit_rate1_2->setText("4.65");
            ui->stackedWidget->setCurrentWidget(ui->page_3);
    }
}

int MainWindow::on_comboBox_year1_2_currentIndexChanged(int index)
{
    double a;
    a=optionrate(ui->comboBox_c_loan1_2->currentIndex(),index,ui->comboBox_rate1_2->currentIndex());
    QString b=QString::number(a);
    ui->lineEdit_rate1_2->setText(b);
    int month;
    month=optionmonth(index);
    return month;
}

void MainWindow::on_comboBox_rate1_2_currentIndexChanged(int index)
{
    double a;
    if(ui->comboBox_c_loan1_2==0) a=4.65;
    else a=3.25;
    a=optionrate(ui->comboBox_c_loan1_2->currentIndex(),ui->comboBox_year1_2->currentIndex(),index);
    QString b=QString::number(a);
    ui->lineEdit_rate1_2->setText(b);

}

void MainWindow::on_pushButton_start1_2_clicked()
{
    QString Yprice = ui->lineEdit_price1_2->text();
    QString Yarea = ui->lineEdit_area1_2->text();
    QString Yrate = ui->lineEdit_rate1_2->text();
    double price = ui->lineEdit_price1_2->text().toDouble();//房屋单价
    double area = ui->lineEdit_area1_2->text().toDouble();//房屋面积
    int month =on_comboBox_year1_2_currentIndexChanged(ui->comboBox_year1_2->currentIndex());//贷款年数
    bool judge = 0;//判断用户输入房屋单价、面积、利率正确与否
    double rate = 0;
    //判断是否为空
    if(!Yprice.isEmpty()&&!Yarea.isEmpty())
    {
        int Ypoint = 0,Yelse=0;
        bool flag1 = 0, flag2 = 0,flag3 = 0;
        for(int i= 0 ;i<Yprice.length();i++)//判断输入单价
        {
            if((Yprice[i]<='9'&&Yprice[i]>='0')||Yprice[i]=='.')
            {
                if(Yprice[i]=='.')
                    Ypoint++;//计算小数点个数
            }
            else Yelse++;//计算非数字\小数点字符个数
            if(Ypoint>1||Yelse!=0){flag1=1;break;}//如果小数点超过一个或者有非数字的情况判断输入为错
        }
        Ypoint = 0;
        Yelse=0;//判断输入面积
        for(int i= 0 ;i<Yarea.length();i++)
        {
            if((Yarea[i]<='9'&&Yarea[i]>='0')||Yarea[i]=='.')
            {
                if(Yarea[i]=='.')
                    Ypoint++;  //计算小数点个数
            }
            else Yelse++;//计算非数字\小数点字符个数
            if(Ypoint>1||Yelse!=0){flag2=1;break;}//如果小数点超过一个或者有非数字的情况判断输入为错
        }
        Ypoint = 0;
        Yelse=0;//判断输入利率
        for(int i= 0 ;i<Yrate.length();i++)
        {
            if((Yrate[i]<='9'&&Yrate[i]>='0')||Yrate[i]=='.')
            {
                if(Yrate[i]=='.')
                    Ypoint++;//计算小数点个数
            }
            else Yelse++;//计算非数字\小数点字符个数
            if(Ypoint>1||Yelse!=0||Yrate.toDouble()==0.0){flag3=1;break;}//如果小数点超过一个或者有非数字的情况判断输入为错
             else rate=Yrate.toDouble();//如果小数点超过一个或者有非数字的情况判断输入为错
        }

        if(flag1 == 1 && flag2 == 1 && flag3 == 1)
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您的输入的房屋单价、面积、利率有误",QMessageBox::Ok);
        }
        else if(flag1 == 1 && flag2 == 0 && flag3 == 0)
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您的输入房屋单价有误",QMessageBox::Ok);
        }
        else if(flag1 == 0 && flag2 == 1 && flag3 == 0)
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您的输入房屋面积有误",QMessageBox::Ok);
        }
        else if(flag1 == 0 && flag2 == 0 && flag3 == 1)
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您的输入房屋利率不合法，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 == 1 && flag2 == 0 && flag3 == 1)
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您的输入房屋单价、利率有误",QMessageBox::Ok);
        }
        else if(flag1 == 0 && flag2 == 1 && flag3 == 1)
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您的输入房屋面积、利率有误",QMessageBox::Ok);
        }
        else if(flag1 == 1 && flag2 == 1 && flag3 == 0)
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您的输入房屋单价、面积有误",QMessageBox::Ok);
        }
        else
        {
            judge = 1;
        }
    }
    //如果有输入有空
    else
    {
        if(Yprice.isEmpty()&&Yarea.isEmpty()&&Yrate.isEmpty())
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","请输入房屋单价、面积、利率",QMessageBox::Ok);
        }
        else if(Yprice.isEmpty()&&!Yarea.isEmpty()&&!Yrate.isEmpty())
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","请输入房屋单价",QMessageBox::Ok);
        }
        else if(!Yprice.isEmpty()&&Yarea.isEmpty()&&!Yrate.isEmpty())
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","请输入房屋面积",QMessageBox::Ok);
        }
        else if(!Yprice.isEmpty()&&!Yarea.isEmpty()&&Yrate.isEmpty())
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","请输入房屋利率",QMessageBox::Ok);
        }
        else if(!Yprice.isEmpty()&&Yarea.isEmpty()&&Yrate.isEmpty())
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","请输入房屋面积、利率",QMessageBox::Ok);
        }
        else if(Yprice.isEmpty()&&!Yarea.isEmpty()&&Yrate.isEmpty())
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","请输入房屋单价、利率",QMessageBox::Ok);
        }
        else if(Yprice.isEmpty()&&Yarea.isEmpty()&&!Yrate.isEmpty())
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","请输入房屋面积、单价",QMessageBox::Ok);
        }
    }

    if(judge ==1 )
    {
        double percent = 0;//按揭成数
        percent=optionpercent(ui->comboBox_percent1_2->currentIndex());
        rate = Yrate.toDouble();
        ui->lineEdit_rate1_2->setText(Yrate);//更新下一页利率
  //调用商贷构造函数
         Commercial_loans  A(area, price,  rate, percent, month);
 //选用哪种利息方式（等额本息）
        if(ui->radioButton_bx1_2->isChecked())
        {
            ui->widget_m_pay1->show();//选择为本息：展示的为每月月供
            ui->widget_fm_pay1->hide();//选择为本息：隐藏的为首月月供
            ui->widget_m_cut1->hide();//选择为本息：隐藏的为每月递减
            A.equal_interest();//等额本息
            ui->label_f_pay1->setText(QString::number(A.Getf_payment(), 'f', 1));//首付
            ui->label_m_pay1->setText(QString::number(A.Getm_supply(), 'f', 1));//每月月供
            ui->label_loans1->setText(QString::number(A.Getloan(), 'f', 1));//贷款总额
            ui->label_interest1->setText(QString::number(A.Getinterest(), 'f', 1));//支付利息
            ui->label_t_repay1->setText(QString::number(A.Gett_repay(), 'f', 1));//还款总额
            ui->label_m1->setText(QString::number(A.Getmonth(), 'f', 0));//还款月数
            ui->radioButton_bx1_2->click();
        }
        //等额本金
        else if(ui->radioButton_bj1_2->isChecked())
        {
            ui->widget_fm_pay1->show();//展示首月月供
            ui->widget_m_cut1->show();//展示每月递减
            ui->widget_m_pay1->hide();//隐藏每月月供
            A.equal_principal();//等额本金
            ui->label_f_pay1->setText(QString::number(A.Getf_payment(), 'f', 1));//首付
            ui->label_fm_pay1->setText(QString::number(A.Getf_supply(), 'f', 1));//首月月供
            ui->label_m_cut1->setText(QString::number(A.Getm_re(), 'f', 1));//每月递减
            ui->label_loans1->setText(QString::number(A.Getloan(), 'f', 1));//贷款总额
            ui->label_interest1->setText(QString::number(A.Getinterest(), 'f', 1));//支付利息
            ui->label_t_repay1->setText(QString::number(A.Gett_repay(), 'f', 1));//还款总额
            ui->label_m1->setText(QString::number(A.Getmonth(), 'f', 0));//还款月数
            ui->radioButton_bj1_2->click();
        }
        ui->stackedWidget->setCurrentWidget(ui->page2);
    }
}

void MainWindow::on_pushButton_remove1_2_clicked()
{
    int reply = QMessageBox::question(this,"Question","是否需要清除数据？");
    if(reply == QMessageBox::Yes)
    {
        if(ui->comboBox_c_loan1_2->currentIndex() == 0)
        {
            ui->comboBox_c_loan1->setCurrentIndex(0);
            ui->lineEdit_rate1->setText("4.65");
        }
        else
        {
            ui->comboBox_c_loan1->setCurrentIndex(1);
            ui->lineEdit_rate1->setText("3.25");
        }
        ui->stackedWidget->setCurrentWidget(ui->page);
        //把单价、面积两个数据清除，并把选项初始化;
        ui->comboBox_c_loan1_2->setCurrentIndex(0);
        ui->lineEdit_price1_2->clear();
        ui->lineEdit_area1_2->clear();
        ui->comboBox_percent1_2->setCurrentIndex(0);
        ui->comboBox_year1_2->setCurrentText(0);
        ui->comboBox_rate1_2->setCurrentText(0);
        ui->lineEdit_rate1_2->setText("4.65");
    }
        //否则继续传递
}
//page4
void MainWindow::on_comboBox_c_loan2_2_currentIndexChanged(int index)
{
    if(index==2)
    {
        ui->comboBox_c_loan3->setCurrentIndex(0);
        ui->comboBox_c_loan2_2->setCurrentIndex(0);
        ui->lineEdit_loans2_2->clear();
        ui->comboBox_year2_2->setCurrentText(0);
        ui->comboBox_rate2_2->setCurrentText(0);
        ui->lineEdit_rate2_2->setText("4.65");
        ui->stackedWidget->setCurrentWidget(ui->page_5);
    }
    else
    {
        if(index==0)
        {
        ui->comboBox_c_loan2->setCurrentIndex(0);
        ui->lineEdit_rate2->setText("4.65");
        ui->stackedWidget->setCurrentWidget(ui->page_3);
        }
        else
        {
        ui->comboBox_c_loan2->setCurrentIndex(1);
        ui->lineEdit_rate2->setText("3.25");
        ui->stackedWidget->setCurrentWidget(ui->page_3);
        }
     }
}

void MainWindow::on_comboBox_calculation2_2_currentIndexChanged(int index)
{
    if(index == 1)
    {
        ui->comboBox_c_loan1->setCurrentIndex(ui->comboBox_c_loan2_2->currentIndex());
        if(ui->comboBox_c_loan1->currentIndex()==0)
            ui->lineEdit_rate1->setText("4.65");
            else
            ui->lineEdit_rate1->setText("3.25");
        ui->comboBox_calculation1->setCurrentIndex(0);
        ui->comboBox_c_loan2_2->setCurrentIndex(0);
        ui->comboBox_c_loan2_2->setCurrentIndex(0);
        ui->lineEdit_loans2_2->clear();
        ui->comboBox_year2_2->setCurrentText(0);
        ui->comboBox_rate2_2->setCurrentText(0);
        ui->lineEdit_rate2_2->setText("4.65");
        ui->stackedWidget->setCurrentWidget(ui->page);
    }
}

int MainWindow::on_comboBox_year2_2_currentIndexChanged(int index)
{
    double a;
    a=optionrate(ui->comboBox_c_loan2_2->currentIndex(),index,ui->comboBox_rate2_2->currentIndex());
QString b=QString::number(a);
ui->lineEdit_rate2_2->setText(b);
int month;
month=optionmonth(index);
return month;
}

void MainWindow::on_comboBox_rate2_2_currentIndexChanged(int index)
{
double a;
if(ui->comboBox_c_loan2_2==0) a=4.65;
else a=3.25;
a=optionrate(ui->comboBox_c_loan2_2->currentIndex(),ui->comboBox_year2_2->currentIndex(),index);
QString b=QString::number(a);
ui->lineEdit_rate2_2->setText(b);
}

void MainWindow::on_pushButton_start2_2_clicked()
{
QString Yloans = ui->lineEdit_loans2_2->text();
QString Yrate = ui->lineEdit_rate2_2->text();
bool judge = 0;//判断用户输入贷款总额正确与否
double rate = 0;
//判断是否为空
if(!Yloans.isEmpty()&&!Yrate.isEmpty())
{
    int Ypoint = 0,Yelse=0;
    bool flag1 = 0, flag2 = 0;
    for(int i= 0 ;i<Yloans.length();i++)//判断输入贷款总额
    {
        if((Yloans[i]<='9'&&Yloans[i]>='0')||Yloans[i]=='.')
        {
            if(Yloans[i]=='.')
                Ypoint++;//计算小数点个数
        }
        else Yelse++;//计算非数字\小数点字符个数
        if(Ypoint>1||Yelse!=0){flag1=1;break;}//如果小数点超过一个或者有非数字的情况判断输入为错
    }
    Ypoint = 0;
    Yelse=0;//判断输入利率
    for(int i= 0 ;i<Yrate.length();i++)
    {
        if((Yrate[i]<='9'&&Yrate[i]>='0')||Yrate[i]=='.')
        {
            if(Yrate[i]=='.')
                Ypoint++;//计算小数点个数
        }
        else Yelse++;//计算非数字\小数点字符个数
        if(Ypoint>1||Yelse!=0||Yrate.toDouble()==0.0){flag2=1;break;}//如果小数点超过一个或者有非数字/=0的情况判断输入为错
         else rate=Yrate.toDouble();
    }

    if(flag1 == 1 && flag2 == 1)
    {
        QMessageBox *eorr = new QMessageBox(this);
        eorr->warning(this,"错误","您的输入的贷款总额、利率有误，请重新输入",QMessageBox::Ok);
    }
    else if(flag1 == 1 && flag2 == 0 )
    {
        QMessageBox *eorr = new QMessageBox(this);
        eorr->warning(this,"错误","您的输入贷款总额有误",QMessageBox::Ok);
    }
    else if(flag1 == 0 && flag2 == 1 )
    {
        QMessageBox *eorr = new QMessageBox(this);
        eorr->warning(this,"错误","您的输入贷款利率不合法，请重新输入",QMessageBox::Ok);
    }
    else
    {
        judge = 1;
    }
}
//如果有输入有空
else
{
    if(Yloans.isEmpty()&&Yrate.isEmpty())
    {
        QMessageBox *eorr = new QMessageBox(this);
        eorr->warning(this,"错误","请输入贷款总额、利率",QMessageBox::Ok);
    }
    else if(Yloans.isEmpty()&&!Yrate.isEmpty())
    {
        QMessageBox *eorr = new QMessageBox(this);
        eorr->warning(this,"错误","请输入贷款总额",QMessageBox::Ok);
    }
    else if(!Yloans.isEmpty()&&Yrate.isEmpty())
    {
        QMessageBox *eorr = new QMessageBox(this);
        eorr->warning(this,"错误","请输入贷款利率",QMessageBox::Ok);
    }
}

if(judge ==1 )
{
    double loans = ui->lineEdit_loans2_2->text().toDouble();
    loans=loans*10000.0;
    rate = Yrate.toDouble();
    int  month=on_comboBox_year2_2_currentIndexChanged(ui->comboBox_year2_2->currentIndex());
    ui->lineEdit_rate2_2->setText(Yrate);//更新下一页利率
    //调用构造函数
    Fund_loans A(loans ,rate , month );
//选用哪种利息方式（等额本息）
    if(ui->radioButton_bx2_2->isChecked())
    {
        ui->widget_m_pay2->show();//选择为本息：展示的为每月月供
        ui->widget_fm_pay2->hide();//选择为本息：隐藏的为首月月供
        ui->widget_m_cut2->hide();//选择为本息：隐藏的为每月递减
        A.equal_interest();//等额本息
        ui->label_m_pay2->setText(QString::number(A.Getm_supply(), 'f', 1));//每月月供
        ui->label_loans2->setText(QString::number(A.Getloan(), 'f', 1));//贷款总额
        ui->label_interest2->setText(QString::number(A.Getinterest(), 'f', 1));//支付利息
        ui->label_t_repay2->setText(QString::number(A.Gett_repay(), 'f', 1));//还款总额
        ui->label_m2->setText(QString::number(A.Getmonth(), 'f', 0));//还款月数
        ui->radioButton_bx2_2->click();
    }
//等额本金
    else if(ui->radioButton_bj2_2->isChecked())
    {
        ui->widget_fm_pay2->show();//展示首月月供
        ui->widget_m_cut2->show();//展示每月递减
        ui->widget_m_pay2->hide();//选择为本息：隐藏的为每月月供
        A.equal_principal();//等额本金
        ui->label_fm_pay2->setText(QString::number(A.Getf_supply(), 'f', 1));//首月月供
        ui->label_m_cut2->setText(QString::number(A.Getm_re(), 'f', 1));//每月递减
        ui->label_loans2->setText(QString::number(A.Getloan(), 'f', 1));//贷款总额
        ui->label_interest2->setText(QString::number(A.Getinterest(), 'f', 1));//支付利息
        ui->label_t_repay2->setText(QString::number(A.Gett_repay(), 'f', 1));//还款总额
        ui->label_m2->setText(QString::number(A.Getmonth(), 'f', 0));//还款月数
        ui->radioButton_bj2_2->click();
    }
    ui->stackedWidget->setCurrentWidget(ui->page_4);
}
}

void MainWindow::on_pushButton_remove2_2_clicked()
{
int reply = QMessageBox::question(this,"Question","是否需要清除数据？");
if(reply == QMessageBox::Yes)
{
    ui->comboBox_c_loan2->setCurrentIndex(ui->comboBox_c_loan2_2->currentIndex());
    if(ui->comboBox_c_loan2_2->currentIndex() == 0)
        ui->lineEdit_rate1->setText("4.65");
    else
    {
        ui->lineEdit_rate1->setText("3.25");
    }
    ui->stackedWidget->setCurrentWidget(ui->page_3);
    //把单价、面积两个数据清除，并把选项初始化;
    ui->comboBox_c_loan2_2->setCurrentIndex(0);
    ui->lineEdit_loans2_2->clear();
    ui->comboBox_year2_2->setCurrentText(0);
    ui->comboBox_rate2_2->setCurrentText(0);
    ui->lineEdit_rate2_2->setText("4.65");
}
    //否则继续传递
}
//page3
void MainWindow::on_comboBox_c_loan2_currentIndexChanged(int index)
{
if(index==2)
{
    ui->comboBox_c_loan3->setCurrentIndex(0);
    ui->stackedWidget->setCurrentWidget(ui->page_5);
    ui->comboBox_c_loan2->setCurrentText(0);
    ui->lineEdit_loans2->clear();
    ui->comboBox_year2->setCurrentText(0);
    ui->comboBox_rate2->setCurrentText(0);
    ui->lineEdit_rate2->setText("4.65");
}
else
{
    if(index==0)
    ui->lineEdit_rate2->setText("4.65");
    else
    ui->lineEdit_rate2->setText("3.25");
 }
}

void MainWindow::on_comboBox_calculation2_currentIndexChanged(int index)
{
if(index == 1)
{
    ui->comboBox_c_loan1->setCurrentIndex(ui->comboBox_c_loan2->currentIndex());
    if(ui->comboBox_c_loan1->currentIndex()==0)
        ui->lineEdit_rate1->setText("4.65");
        else
        ui->lineEdit_rate1->setText("3.25");
    ui->comboBox_calculation1->setCurrentIndex(0);
    ui->stackedWidget->setCurrentWidget(ui->page);
    ui->comboBox_c_loan2->setCurrentIndex(0);
    ui->comboBox_c_loan2->setCurrentIndex(0);
    ui->lineEdit_loans2->clear();
    ui->comboBox_year2->setCurrentText(0);
    ui->comboBox_rate2->setCurrentText(0);
    ui->lineEdit_rate2->setText("4.65");
}
}

int MainWindow::on_comboBox_year2_currentIndexChanged(int index)
{
double a;
a=optionrate(ui->comboBox_c_loan2->currentIndex(),index,ui->comboBox_rate2->currentIndex());
QString b=QString::number(a);
ui->lineEdit_rate2->setText(b);
int month;
month=optionmonth(index);
return month;
}

void MainWindow::on_comboBox_rate2_currentIndexChanged(int index)
{
double a;
if(ui->comboBox_c_loan2==0) a=4.65;
else a=3.25;
a=optionrate(ui->comboBox_c_loan2->currentIndex(),ui->comboBox_year2->currentIndex(),index);
QString b=QString::number(a);
ui->lineEdit_rate2->setText(b);
}

void MainWindow::on_pushButton_start2_clicked()
{
QString Yloans = ui->lineEdit_loans2->text();
QString Yrate = ui->lineEdit_rate2->text();
bool judge = 0;//判断用户输入贷款总额正确与否
double rate = 0;
//判断是否为空
if(!Yloans.isEmpty()&&!Yrate.isEmpty())
{
    int Ypoint = 0,Yelse=0;
    bool flag1 = 0, flag2 = 0;
    for(int i= 0 ;i<Yloans.length();i++)//判断输入贷款总额
    {
        if((Yloans[i]<='9'&&Yloans[i]>='0')||Yloans[i]=='.')
        {
            if(Yloans[i]=='.')
                Ypoint++;//计算小数点个数
        }
        else Yelse++;//计算非数字\小数点字符个数
        if(Ypoint>1||Yelse!=0){flag1=1;break;}//如果小数点超过一个或者有非数字的情况判断输入为错
    }
    Ypoint = 0;
    Yelse=0;//判断输入利率
    for(int i= 0 ;i<Yrate.length();i++)
    {
        if((Yrate[i]<='9'&&Yrate[i]>='0')||Yrate[i]=='.')
        {
            if(Yrate[i]=='.')
                Ypoint++;//计算小数点个数
        }
        else Yelse++;//计算非数字\小数点字符个数
        if(Ypoint>1||Yelse!=0||Yrate.toDouble()==0.0){flag2=1;break;}//如果小数点超过一个或者有非数字/=0的情况判断输入为错
         else rate=Yrate.toDouble();
    }

    if(flag1 == 1 && flag2 == 1)
    {
        QMessageBox *eorr = new QMessageBox(this);
        eorr->warning(this,"错误","您的输入的贷款总额、利率有误，请重新输入",QMessageBox::Ok);
    }
    else if(flag1 == 1 && flag2 == 0 )
    {
        QMessageBox *eorr = new QMessageBox(this);
        eorr->warning(this,"错误","您的输入贷款总额有误",QMessageBox::Ok);
    }
    else if(flag1 == 0 && flag2 == 1 )
    {
        QMessageBox *eorr = new QMessageBox(this);
        eorr->warning(this,"错误","您的输入贷款利率不合法，请重新输入",QMessageBox::Ok);
    }
    else
    {
        judge = 1;
    }
}
//如果有输入有空
else
{
    if(Yloans.isEmpty()&&Yrate.isEmpty())
    {
        QMessageBox *eorr = new QMessageBox(this);
        eorr->warning(this,"错误","请输入贷款总额、利率",QMessageBox::Ok);
    }
    else if(Yloans.isEmpty()&&!Yrate.isEmpty())
    {
        QMessageBox *eorr = new QMessageBox(this);
        eorr->warning(this,"错误","请输入贷款总额",QMessageBox::Ok);
    }
    else if(!Yloans.isEmpty()&&Yrate.isEmpty())
    {
        QMessageBox *eorr = new QMessageBox(this);
        eorr->warning(this,"错误","请输入贷款利率",QMessageBox::Ok);
    }
}

if(judge ==1 )
{
    double loans = ui->lineEdit_loans2->text().toDouble();
    loans=loans*10000;
    int  month=on_comboBox_year2_currentIndexChanged(ui->comboBox_year2->currentIndex());
    rate = Yrate.toDouble();
    ui->comboBox_c_loan2_2->setCurrentIndex(ui->comboBox_c_loan2->currentIndex());//更新贷款类型
    ui->comboBox_calculation2_2->setCurrentIndex(0);
    ui->lineEdit_loans2_2->setText(ui->lineEdit_loans2->text());//更新下一页数据（贷款总额）
    ui->comboBox_year2_2->setCurrentIndex(ui->comboBox_year2->currentIndex());//更新下一页数据（日期）
    ui->comboBox_rate2_2->setCurrentIndex(ui->comboBox_rate2->currentIndex());//更新下一页利率选项
    ui->lineEdit_rate2_2->setText(Yrate);//更新下一页利率
    //调用构造函数
    Fund_loans A(loans ,rate , month );
//选用哪种利息方式（等额本息）
    if(ui->radioButton_bx2->isChecked())
    {
        ui->widget_m_pay2->show();//选择为本息：展示的为每月月供
        ui->widget_fm_pay2->hide();//选择为本息：隐藏的为首月月供
        ui->widget_m_cut2->hide();//选择为本息：隐藏的为每月递减
        A.equal_interest();//等额本息
        ui->label_m_pay2->setText(QString::number(A.Getm_supply(), 'f', 1));//每月月供
        ui->label_loans2->setText(QString::number(A.Getloan(), 'f', 1));//贷款总额
        ui->label_interest2->setText(QString::number(A.Getinterest(), 'f', 1));//支付利息
        ui->label_t_repay2->setText(QString::number(A.Gett_repay(), 'f', 1));//还款总额
        ui->label_m2->setText(QString::number(A.Getmonth(), 'f', 0));//还款月数
        ui->radioButton_bx2_2->click();
    }
//等额本金
    else if(ui->radioButton_bj2->isChecked())
    {
        ui->widget_fm_pay2->show();//展示首月月供
        ui->widget_m_cut2->show();//展示每月递减
        ui->widget_m_pay2->hide();//隐藏的每月月供
        A.equal_principal();//等额本金
        ui->label_fm_pay2->setText(QString::number(A.Getf_supply(), 'f', 1));//首月月供
        ui->label_m_cut2->setText(QString::number(A.Getm_re(), 'f', 1));//每月递减
        ui->label_loans2->setText(QString::number(A.Getloan(), 'f', 1));//贷款总额
        ui->label_interest2->setText(QString::number(A.Getinterest(), 'f', 1));//支付利息
        ui->label_t_repay2->setText(QString::number(A.Gett_repay(), 'f', 1));//还款总额
        ui->label_m2->setText(QString::number(A.Getmonth(), 'f', 0));//还款月数
        ui->radioButton_bj2_2->click();
    }
    ui->stackedWidget->setCurrentWidget(ui->page_4);
    ui->comboBox_c_loan2->setCurrentIndex(0);
    ui->lineEdit_loans2->clear();
    ui->comboBox_year2->setCurrentText(0);
    ui->comboBox_rate2->setCurrentText(0);
    ui->lineEdit_rate2->setText("4.65");
}
}

void MainWindow::on_pushButton_remove2_clicked()
{
int reply = QMessageBox::question(this,"Question","是否需要清除数据？");
if(reply == QMessageBox::Yes)
{
    //把单价、面积两个数据清除，并把选项初始化;
    ui->lineEdit_loans2->clear();
    ui->comboBox_year2->setCurrentText(0);
    ui->comboBox_rate2->setCurrentText(0);
    if(ui->comboBox_c_loan2->currentIndex() == 0)
        ui->lineEdit_rate2->setText("4.65");
    else
    {
        ui->lineEdit_rate2->setText("3.25");
    }
}
    //否则继续传递
}
//page5
void MainWindow::on_comboBox_c_loan3_currentIndexChanged(int index)
{
if(index == 1|| index == 2)
{
    ui->comboBox_c_loan1->setCurrentIndex(index-1);
    if(ui->comboBox_c_loan1->currentIndex()==0)
        ui->lineEdit_rate1->setText("4.65");
        else
        ui->lineEdit_rate1->setText("3.25");
    ui->comboBox_calculation1->setCurrentIndex(0);
    ui->stackedWidget->setCurrentWidget(ui->page);
    ui->lineEdit_c_loan3->clear();
    ui->lineEdit_h_loan3->clear();
    ui->comboBox_year3->setCurrentText(0);
    ui->comboBox_c_rate3->setCurrentText(0);
    ui->comboBox_h_rate3->setCurrentText(0);
        ui->lineEdit_c_rate3->setText("3.25");
        ui->lineEdit_h_rate3->setText("3.25");
}
}

void MainWindow::on_comboBox_c_rate3_currentIndexChanged(int index)
{
double a=3.25;
a=optionrate1(ui->comboBox_year3->currentIndex(),index);
QString b=QString::number(a);
ui->lineEdit_c_rate3->setText(b);
}

void MainWindow::on_comboBox_h_rate3_currentIndexChanged(int index)
{
double a=3.25;
a=optionrate1(ui->comboBox_year3->currentIndex(),index);
QString b=QString::number(a);
ui->lineEdit_h_rate3->setText(b);
}

int MainWindow::on_comboBox_year3_currentIndexChanged(int index)
{
double a=3.25;
a=optionrate1(index,ui->comboBox_c_rate3->currentIndex());
QString b=QString::number(a);
ui->lineEdit_h_rate3->setText(b);
ui->lineEdit_c_rate3->setText(b);
int month;
month=optionmonth(index);
return month;
}

void MainWindow::on_pushButton_start3_clicked()
{
ui->comboBox_c_loan3_2->setCurrentIndex(0);
QString CLoan= ui->lineEdit_c_loan3->text();
QString HLoan = ui->lineEdit_h_loan3->text();
QString CRate= ui->lineEdit_c_rate3->text();
QString HRate = ui->lineEdit_h_rate3->text();
bool Justise = 0;
double crate = 0.0,hrate = 0.0;
//判断是否为空
if(!CLoan.isEmpty()&&!HLoan.isEmpty()&&!CRate.isEmpty()&&!HRate.isEmpty())
{
    int YPoint = 0,Yelse=0;
    bool flag1 = 0,flag2 = 0,flag3 = 0, flag4 = 0;
//判断商贷额度输入
    for(int i= 0 ;i<CLoan.length();i++)
    {
        if((CLoan[i]<='9'&&CLoan[i]>='0')||CLoan[i]=='.')
        {
            if(CLoan[i]=='.')
                YPoint++;
        }
        else Yelse++;
        if(YPoint>1||Yelse!=0) { flag1=1; break;  }
    }
//判断公积金额度输入
    YPoint = 0;
    Yelse=0;
    for(int i= 0 ;i<HLoan.length();i++)
    {
        if((HLoan[i]<='9'&&HLoan[i]>='0')||HLoan[i]=='.')
        {
            if(HLoan[i]=='.')
                YPoint++;
        }
        else Yelse++;
        if(YPoint>1||Yelse!=0) { flag2=1; break; }
    }
//判断输入商贷利率
    YPoint = 0;
    Yelse=0;
    for(int i= 0 ;i<CRate.length();i++)
    {
        if((CRate[i]<='9'&&CRate[i]>='0')||CRate[i]=='.')
        {
            if(CRate[i]=='.')
           YPoint++;
        }
        else Yelse++;
        if(YPoint>1||Yelse!=0||CRate.toDouble()==0.0) { flag3=1; break; }
    }
//判断输入公基金贷款利率
    YPoint = 0;
    Yelse=0;
    for(int i= 0 ;i<HRate.length();i++)
    {
    if((HRate[i]>='0'&&HRate[i]<='9')||HRate[i]=='.')
    {
        if(HRate[i]=='.')
        YPoint++;
    }
    else Yelse++;
    if(YPoint>1||Yelse!=0||HRate.toDouble()==0.0) { flag4=1; break; }
    }

    if(flag1 == 1 || flag3 == 1 || flag2 == 1 || flag4 == 1)
    {
        if(flag1 == 1 && flag1 == 1 && flag2 == 1 && flag3 == 1)
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的房屋商业贷款额及其利率，公积金贷款额及其利率有误",QMessageBox::Ok);
        }
        else if(flag1 == 1 &&flag2 == 0 && flag3 == 0 && flag4 == 0)
        {
           QMessageBox *eorr = new QMessageBox(this);
           eorr->warning(this,"错误","您输入的商业贷款额有误",QMessageBox::Ok);
        }
        else if(flag1 == 0 &&flag2 == 1 && flag3 == 0 && flag4 == 0)
        {
             QMessageBox *eorr = new QMessageBox(this);
             eorr->warning(this,"错误","您输入的公积金贷款额有误",QMessageBox::Ok);
        }
        else if(flag1 == 0 &&flag2 == 0 && flag3 == 1 && flag4 == 0)
        {
              QMessageBox *eorr = new QMessageBox(this);
              eorr->warning(this,"错误","您输入的商贷利率不合法，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 == 0 &&flag2 == 0 && flag3 == 0 && flag4 == 1)
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的公积金利率不合法，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 ==1 &&flag2==1 && flag3 == 0 &&flag4 == 0 )
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的商业贷款额、公积金贷款额有误，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 ==1 &&flag2== 0&& flag3 == 1 &&flag4 == 0 )
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的商业贷款额及其利率，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 ==1 &&flag2==0 && flag3 == 0 &&flag4 == 1 )
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的商业贷款额、公积金利率有误，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 ==0 &&flag2==1 && flag3 == 1 &&flag4 == 0 )
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的公积金贷款额、商贷利率有误，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 ==0 &&flag2==1 && flag3 == 0 &&flag4 == 1 )
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的公积金贷款额及其利率有误，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 ==0 &&flag2==0 && flag3 == 1 &&flag4 == 1 )
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的商贷利率、公积金利率不合法，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 ==1 &&flag2==1 && flag3 == 1 &&flag4 == 0 )
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的商业贷款额、公积金贷款额、商贷利率有误，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 ==1 &&flag2==1 && flag3 == 0 &&flag4 == 1 )
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的商业贷款额、公积金贷款额、公积金利率有误，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 ==1 &&flag2==0 && flag3 == 1 &&flag4 == 1 )
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的商业贷款额、商贷利率、公积金利率有误，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 ==0 &&flag2==1 && flag3 == 1 &&flag4 == 1 )
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的商业贷款额、商贷利率、公积金利率有误，请重新输入",QMessageBox::Ok);
        }
    }
    else
        Justise = 1;
}
else//如果有输入有空
{
    if(CLoan.isEmpty()&&CLoan.isEmpty())
    {
        QMessageBox *eorr = new QMessageBox(this);
        eorr->warning(this,"错误","请输入商业贷款额、公积金贷款额",QMessageBox::Ok);
    }
    else if(CLoan.isEmpty()&&!HLoan.isEmpty())
    {
        QMessageBox *eorr = new QMessageBox(this);
        eorr->warning(this,"错误","请输入商业贷款额",QMessageBox::Ok);
    }
    else if(!CLoan.isEmpty()&&HLoan.isEmpty())
    {
        QMessageBox *eorr = new QMessageBox(this);
        eorr->warning(this,"错误","请输入公积金贷款额",QMessageBox::Ok);
    }
    else
    {
        QMessageBox *eorr = new QMessageBox(this);
        eorr->warning(this,"错误","您有未输入的选项，请仔细检查",QMessageBox::Ok);
    }
}

if(Justise ==1 )
{
    double cloans = ui->lineEdit_c_loan3->text().toDouble();
    cloans= cloans*10000.0;//商贷总额
    double hloans = ui->lineEdit_h_loan3->text().toDouble();
    hloans= 10000.0*hloans;//公积金贷款额
    hrate = HRate.toDouble();
    crate = CRate.toDouble();

    ui->lineEdit_c_loan3_2->setText(ui->lineEdit_c_loan3->text());
    ui->lineEdit_h_loan3_2->setText(ui->lineEdit_h_loan3->text());
    int month = on_comboBox_year3_currentIndexChanged(ui->comboBox_year3->currentIndex());
//贷款类型
    ui->comboBox_c_loan3_2->setCurrentIndex(ui->comboBox_c_loan3->currentIndex());
//商贷
    ui->comboBox_c_rate3_2->setCurrentIndex(ui->comboBox_c_rate3->currentIndex());//更新下一页数据（利率选项）
    ui->lineEdit_c_rate3_2->setText(CRate);//更新下一页数据（利率）
//公积金贷
    ui->comboBox_h_rate3_2->setCurrentIndex(ui->comboBox_h_rate3->currentIndex());//更新下一页数据（利率选项）
    ui->lineEdit_h_rate3_2->setText(HRate);//更新下一页数据（利率）

    ui->comboBox_year3_2->setCurrentIndex(ui->comboBox_year3->currentIndex());

    Fund_loans A(cloans,crate,month);//商贷
    Fund_loans B(hloans,hrate,month);//公积金贷

    //等额本息
    if(ui->radioButton_bx3->isChecked())
    {
        ui->widget_m_pay3->show();
        ui->widget_fm_pay3->hide();//隐藏首月月供
        ui->widget_m_cut3->hide();//隐藏每月递减
        A.equal_interest();
        B.equal_interest();
        ui->label_m_pay3->setText(QString::number(A.Getm_supply()+B.Getm_supply(), 'f', 1));//每月月供
        ui->label_loans3->setText(QString::number(A.Getloan()+B.Getloan(), 'f', 1));//贷款总额
        ui->label_interest3->setText(QString::number(A.Getinterest()+B.Getinterest(), 'f', 1));//支付利息
        ui->label_t_repay3->setText(QString::number(A.Gett_repay()+B.Gett_repay(), 'f', 1));//还款总额
        ui->label_m3->setText(QString::number(A.Getmonth(), 'f', 1));//还款月数
    ui->radioButton_bx3_2->click();
    }
    //等额本金
    else if(ui->radioButton_bj3->isChecked())
    {
        ui->widget_m_pay3->hide();//隐藏每月月供
        ui->widget_fm_pay3->show();//展示首月月供
        ui->widget_m_cut3->show();//展示每月递减
        A.equal_principal();
        B.equal_principal();
        ui->label_fm_pay3->setText(QString::number(A.Getf_supply()+B.Getf_supply(), 'f', 1));//首月月供
        ui->label_m_cut3->setText(QString::number(A.Getm_re()+B.Getm_re(), 'f', 1));//每月递减
        ui->label_loans3->setText(QString::number(A.Getloan()+B.Getloan(), 'f', 1));//贷款总额
        ui->label_interest3->setText(QString::number(A.Getinterest()+B.Getinterest(), 'f', 1));//支付利息
        ui->label_t_repay3->setText(QString::number(A.Gett_repay()+B.Gett_repay(), 'f', 1));//还款总额
        ui->label_m3->setText(QString::number(A.Getmonth(), 'f', 0));//还款月数
        ui->radioButton_bj3_2->clicked();
    }
    ui->stackedWidget->setCurrentWidget(ui->page_6);
    ui->lineEdit_c_loan3->clear();
    ui->lineEdit_h_loan3->clear();
    ui->comboBox_year3->setCurrentText(0);
    ui->comboBox_c_rate3->setCurrentText(0);
    ui->comboBox_h_rate3->setCurrentText(0);
        ui->lineEdit_c_rate3->setText("3.25");
        ui->lineEdit_h_rate3->setText("3.25");
}

}

void MainWindow::on_pushButton_remove3_clicked()
{
int reply = QMessageBox::question(this,"Question","是否需要清除数据？");
if(reply == QMessageBox::Yes)
{
    //把商贷、公积金贷两个数据清除，并把选项初始化;
    ui->lineEdit_c_loan3->clear();
    ui->lineEdit_h_loan3->clear();
    ui->comboBox_year3->setCurrentText(0);
    ui->comboBox_c_rate3->setCurrentText(0);
    ui->comboBox_h_rate3->setCurrentText(0);
        ui->lineEdit_c_rate3->setText("3.25");
        ui->lineEdit_h_rate3->setText("3.25");
}
    //否则继续传递
}

//page6
void MainWindow::on_comboBox_c_loan3_2_currentIndexChanged(int index)
{
if(index == 1|| index == 2)
{
    ui->comboBox_c_loan1->setCurrentIndex(index-1);
    ui->comboBox_calculation1->setCurrentIndex(0);
    if(ui->comboBox_c_loan1->currentIndex()==0)
        ui->lineEdit_rate1->setText("4.65");
        else
        ui->lineEdit_rate1->setText("3.25");
    ui->stackedWidget->setCurrentWidget(ui->page);
    ui->lineEdit_c_loan3_2->clear();
    ui->lineEdit_h_loan3_2->clear();
    ui->comboBox_year3_2->setCurrentText(0);
    ui->comboBox_c_rate3_2->setCurrentText(0);
    ui->comboBox_h_rate3_2->setCurrentText(0);
    ui->lineEdit_c_rate3_2->setText("3.25");
    ui->lineEdit_h_rate3_2->setText("3.25");
}
}

void MainWindow::on_comboBox_c_rate3_2_currentIndexChanged(int index)
{
double a=3.25;
a=optionrate1(ui->comboBox_year3_2->currentIndex(),index);
QString b=QString::number(a);
ui->lineEdit_c_rate3_2->setText(b);
}

void MainWindow::on_comboBox_h_rate3_2_currentIndexChanged(int index)
{
double a=3.25;
a=optionrate1(ui->comboBox_year3->currentIndex(),index);
QString b=QString::number(a);
ui->lineEdit_h_rate3->setText(b);
}

int MainWindow::on_comboBox_year3_2_currentIndexChanged(int index)
{
double a=3.25;
a=optionrate1(index,ui->comboBox_c_rate3_2->currentIndex());
QString b=QString::number(a);
ui->lineEdit_h_rate3_2->setText(b);
ui->lineEdit_c_rate3_2->setText(b);
int month;
month=optionmonth(index);
return month;
}

void MainWindow::on_pushButton_start3_2_clicked()
{
ui->comboBox_c_loan3_2->setCurrentIndex(0);
QString CLoan= ui->lineEdit_c_loan3_2->text();
QString HLoan = ui->lineEdit_h_loan3_2->text();
QString CRate= ui->lineEdit_c_rate3_2->text();
QString HRate = ui->lineEdit_h_rate3_2->text();
bool Justise = 0;
double crate = 0,hrate = 0;
//判断是否为空
if(!CLoan.isEmpty()&&!HLoan.isEmpty()&&!CRate.isEmpty()&&!HRate.isEmpty())
{
    int YPoint = 0,Yelse=0;
    bool flag1 = 0,flag2 = 0,flag3 = 0, flag4 = 0;
//判断商贷额度输入
    for(int i= 0 ;i<CLoan.length();i++)
    {
        if((CLoan[i]<='9'&&CLoan[i]>='0')||CLoan[i]=='.')
        {
            if(CLoan[i]=='.')
                YPoint++;
        }
        else Yelse++;
        if(YPoint>1||Yelse!=0) { flag1=1; break;  }
    }
//判断公积金额度输入
    YPoint = 0;
    Yelse=0;
    for(int i= 0 ;i<HLoan.length();i++)
    {
        if((HLoan[i]<='9'&&HLoan[i]>='0')||HLoan[i]=='.')
        {
            if(HLoan[i]=='.')
                YPoint++;
        }
        else Yelse++;
        if(YPoint>1||Yelse!=0) { flag2=1; break; }
    }
//判断输入商贷利率
    YPoint = 0;
    Yelse=0;
    for(int i= 0 ;i<CRate.length();i++)
    {
        if((CRate[i]<='9'&&CRate[i]>='0')||CRate[i]=='.')
        {
            if(CRate[i]=='.')
           YPoint++;
        }
        else Yelse++;
        if(YPoint>1||Yelse!=0||CRate.toDouble()==0.0) { flag3=1; break; }
    }
//判断输入公基金贷款利率
    YPoint = 0;
    Yelse=0;
    for(int i= 0 ;i<HRate.length();i++)
    {
    if((HRate[i]>='0'&&HRate[i]<='9')||HRate[i]=='.')
    {
        if(HRate[i]=='.')
        YPoint++;
    }
    else Yelse++;
    if(YPoint>1||Yelse!=0||HRate.toDouble()==0.0) { flag4=1; break; }
    }

    if(flag1 == 1 || flag3 == 1 || flag2 == 1 || flag4 == 1)
    {
        if(flag1 == 1 && flag1 == 1 && flag2 == 1 && flag3 == 1)
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的房屋商业贷款额及其利率，公积金贷款额及其利率有误",QMessageBox::Ok);
        }
        else if(flag1 == 1 &&flag2 == 0 && flag3 == 0 && flag4 == 0)
        {
           QMessageBox *eorr = new QMessageBox(this);
           eorr->warning(this,"错误","您输入的商业贷款额有误",QMessageBox::Ok);
        }
        else if(flag1 == 0 &&flag2 == 1 && flag3 == 0 && flag4 == 0)
        {
             QMessageBox *eorr = new QMessageBox(this);
             eorr->warning(this,"错误","您输入的公积金贷款额有误",QMessageBox::Ok);
        }
        else if(flag1 == 0 &&flag2 == 0 && flag3 == 1 && flag4 == 0)
        {
              QMessageBox *eorr = new QMessageBox(this);
              eorr->warning(this,"错误","您输入的商贷利率不合法，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 == 0 &&flag2 == 0 && flag3 == 0 && flag4 == 1)
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的公积金利率不合法，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 ==1 &&flag2==1 && flag3 == 0 &&flag4 == 0 )
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的商业贷款额、公积金贷款额有误，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 ==1 &&flag2== 0&& flag3 == 1 &&flag4 == 0 )
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的商业贷款额及其利率，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 ==1 &&flag2==0 && flag3 == 0 &&flag4 == 1 )
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的商业贷款额、公积金利率有误，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 ==0 &&flag2==1 && flag3 == 1 &&flag4 == 0 )
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的公积金贷款额、商贷利率有误，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 ==0 &&flag2==1 && flag3 == 0 &&flag4 == 1 )
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的公积金贷款额及其利率有误，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 ==0 &&flag2==0 && flag3 == 1 &&flag4 == 1 )
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的商贷利率、公积金利率不合法，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 ==1 &&flag2==1 && flag3 == 1 &&flag4 == 0 )
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的商业贷款额、公积金贷款额、商贷利率有误，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 ==1 &&flag2==1 && flag3 == 0 &&flag4 == 1 )
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的商业贷款额、公积金贷款额、公积金利率有误，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 ==1 &&flag2==0 && flag3 == 1 &&flag4 == 1 )
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的商业贷款额、商贷利率、公积金利率有误，请重新输入",QMessageBox::Ok);
        }
        else if(flag1 ==0 &&flag2==1 && flag3 == 1 &&flag4 == 1 )
        {
            QMessageBox *eorr = new QMessageBox(this);
            eorr->warning(this,"错误","您输入的商业贷款额、商贷利率、公积金利率有误，请重新输入",QMessageBox::Ok);
        }
    }
    else
        Justise = 1;
}
//如果有输入有空
else
{
    if(CLoan.isEmpty()&&CLoan.isEmpty())
    {
        QMessageBox *eorr = new QMessageBox(this);
        eorr->warning(this,"错误","请输入商业贷款额、公积金贷款额",QMessageBox::Ok);
    }
    else if(CLoan.isEmpty()&&!HLoan.isEmpty())
    {
        QMessageBox *eorr = new QMessageBox(this);
        eorr->warning(this,"错误","请输入商业贷款额",QMessageBox::Ok);
    }
    else if(!CLoan.isEmpty()&&HLoan.isEmpty())
    {
        QMessageBox *eorr = new QMessageBox(this);
        eorr->warning(this,"错误","请输入公积金贷款额",QMessageBox::Ok);
    }
    else
    {
        QMessageBox *eorr = new QMessageBox(this);
        eorr->warning(this,"错误","您有未输入的选项，请仔细检查",QMessageBox::Ok);
    }
}

if(Justise ==1 )
{
    double cloans = ui->lineEdit_c_loan3_2->text().toDouble();
    cloans= cloans*10000.0;//商贷总额
    double hloans = ui->lineEdit_h_loan3_2->text().toDouble();
    hloans= 10000.0*hloans;//公积金贷款额
    hrate = HRate.toDouble();
    crate = CRate.toDouble();

    int month = on_comboBox_year3_2_currentIndexChanged(ui->comboBox_year3_2->currentIndex());

    ui->lineEdit_c_rate3_2->setText(CRate);//更新下一页数据（利率）
    ui->lineEdit_h_rate3_2->setText(HRate);//更新下一页数据（利率）

    Fund_loans A(cloans,crate,month);//商贷
    Fund_loans B(hloans,hrate,month);//公积金贷

    //等额本息
    if(ui->radioButton_bx3_2->isChecked())
    {
        ui->widget_m_pay3->show();//展示每月月供
        ui->widget_fm_pay3->hide();//隐藏首月月供
        ui->widget_m_cut3->hide();//隐藏每月递减
        A.equal_interest();
        B.equal_interest();
        ui->label_m_pay3->setText(QString::number(A.Getm_supply()+B.Getm_supply(), 'f', 1));//每月月供
        ui->label_loans3->setText(QString::number(A.Getloan()+B.Getloan(), 'f', 1));//贷款总额
        ui->label_interest3->setText(QString::number(A.Getinterest()+B.Getinterest(), 'f', 1));//支付利息
        ui->label_t_repay3->setText(QString::number(A.Gett_repay()+B.Gett_repay(), 'f', 1));//还款总额
        ui->label_m3->setText(QString::number(A.Getmonth(), 'f', 1));//还款月数
    ui->radioButton_bx3_2->click();
    }
    //等额本金
    else if(ui->radioButton_bj3_2->isChecked())
    {
        ui->widget_m_pay3->hide();//隐藏每月月供
        ui->widget_fm_pay3->show();//展示首月月供
        ui->widget_m_cut3->show();//展示每月递减
        A.equal_principal();
        B.equal_principal();
        ui->label_fm_pay3->setText(QString::number(A.Getf_supply()+B.Getf_supply(), 'f', 1));//首月月供
        ui->label_m_cut3->setText(QString::number(A.Getm_re()+B.Getm_re(), 'f', 1));//每月递减
        ui->label_loans3->setText(QString::number(A.Getloan()+B.Getloan(), 'f', 1));//贷款总额
        ui->label_interest3->setText(QString::number(A.Getinterest()+B.Getinterest(), 'f', 1));//支付利息
        ui->label_t_repay3->setText(QString::number(A.Gett_repay()+B.Gett_repay(), 'f', 1));//还款总额
        ui->label_m3->setText(QString::number(A.Getmonth(), 'f', 0));//还款月数
        ui->radioButton_bj3_2->clicked();
    }
    ui->stackedWidget->setCurrentWidget(ui->page_6);
}

}

void MainWindow::on_pushButton_remove3_2_clicked()
{
int reply = QMessageBox::question(this,"Question","是否需要清除数据？");
if(reply == QMessageBox::Yes)
{
     //把商贷、公积金贷两个数据清除，并把选项初始化;
    ui->stackedWidget->setCurrentWidget(ui->page_5);
    ui->lineEdit_c_loan3_2->clear();
    ui->lineEdit_h_loan3_2->clear();
    ui->comboBox_year3_2->setCurrentText(0);
    ui->comboBox_c_rate3_2->setCurrentText(0);
    ui->comboBox_h_rate3_2->setCurrentText(0);
    ui->lineEdit_c_rate3_2->setText("3.25");
    ui->lineEdit_h_rate3_2->setText("3.25");
}
    //否则继续传递
}
