#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include <QWidget>
#include<QMessageBox>
#include<QCloseEvent>
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void closeEvent(QCloseEvent *close)override;
private slots:

    //page
    void on_comboBox_c_loan1_currentIndexChanged(int index);

    void on_comboBox_calculation1_currentIndexChanged(int index);

    int on_comboBox_year1_currentIndexChanged(int index);

    void on_comboBox_rate1_currentIndexChanged(int index);

    void on_pushButton_start1_clicked();

    void on_pushButton_remove1_clicked();

    //page2
    void on_comboBox_c_loan1_2_currentIndexChanged(int index);

    void on_comboBox_calculation1_2_currentIndexChanged(int index);

    int on_comboBox_year1_2_currentIndexChanged(int index);

    void on_comboBox_rate1_2_currentIndexChanged(int index);

    void on_pushButton_start1_2_clicked();

    void on_pushButton_remove1_2_clicked();

    //page4
    void on_comboBox_c_loan2_2_currentIndexChanged(int index);

    void on_comboBox_calculation2_2_currentIndexChanged(int index);

    int on_comboBox_year2_2_currentIndexChanged(int index);

    void on_comboBox_rate2_2_currentIndexChanged(int index);

    void on_pushButton_start2_2_clicked();

    void on_pushButton_remove2_2_clicked();

    //page3
    void on_comboBox_c_loan2_currentIndexChanged(int index);

    void on_comboBox_calculation2_currentIndexChanged(int index);

    int on_comboBox_year2_currentIndexChanged(int index);

    void on_comboBox_rate2_currentIndexChanged(int index);

    void on_pushButton_start2_clicked();

    void on_pushButton_remove2_clicked();

    //page5
    void on_comboBox_c_loan3_currentIndexChanged(int index);

    void on_comboBox_c_rate3_currentIndexChanged(int index);

    void on_comboBox_h_rate3_currentIndexChanged(int index);

    int on_comboBox_year3_currentIndexChanged(int index);

    void on_pushButton_start3_clicked();

    void on_pushButton_remove3_clicked();

    //page6
    void on_comboBox_c_loan3_2_currentIndexChanged(int index);

    void on_comboBox_c_rate3_2_currentIndexChanged(int index);

    void on_comboBox_h_rate3_2_currentIndexChanged(int index);

    int on_comboBox_year3_2_currentIndexChanged(int index);

    void on_pushButton_start3_2_clicked();

    void on_pushButton_remove3_2_clicked();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
